# Author: Priyanka Karia, Manish Walia
# Create Date: 16th Feb 2018
# Modified Date: 17th Feb 2018

# References: stackoverflow.com

import os
import sys
import requests
import bs4
from bs4 import BeautifulSoup
import openpyxl
import csv


def downloadData(file_path):
    """This method scrapes data such as job title, location, company name, job summary and salary from indeed.com
    based on the search term and stores the results in a xlsx file on the path specified."""

    wb = openpyxl.Workbook()  # Create a new workbook object
    wb.save(file_path)  # Save the file
    option = ''

    while option!='n':
        """Create empty lists to store information accordingly."""
        job_titles = list()
        locations = list()
        companies = list()
        summary = list()
        salaries = list()

        search_term = input("\nEnter search term:")

        for i in range(0, 100, 10): #Extract data from first 10 pages
            url = 'https://www.indeed.com/jobs?q=' + search_term + "&start=" + str(i)
            response = requests.get(url)  # Get the response from the url
            data = response.text  # Convert to text
            soup = BeautifulSoup(data, 'html.parser')  # Parse the html response

            divs = soup.find_all(name="div", attrs={"class": "row"})

            # Get the job titles
            for div in divs:
                 for a in div.find_all(name="a", attrs={"data-tn-element": "jobTitle"}):
                    job_titles.append(a["title"])

            # Get the locations
            for a in soup.find_all(name="span", attrs={"class": "location"}):
                locations.append(a.text)

            # Get the company names
            for div in divs:
                for a in div.find_all(name="span", attrs={"class": "company"}):
                    companies.append(a.text.strip())

            # Get job summary
            for a in soup.find_all(name="span", attrs={"class": "summary"}):
                summary.append(a.text.strip())

            # Get salary
            for div in soup.find_all(name="div", attrs={"class": "row"}):
                try:
                    div2 = div.find(name="div", attrs={"class": "sjcl"})
                    div3 = div2.find("div")
                    salaries.append(div3.text.strip())
                except:
                    salaries.append("Not available")

        job_titles = ['Job Title'] + job_titles
        companies = ['Company Name'] + companies
        locations = ['Location'] + locations
        summary = ['Summary'] + summary
        salaries = ['Salary'] + salaries

        # Write the data in the csv file
        l = zip(job_titles,companies,locations,summary,salaries) #Combine all the lists
        with open(file_path, 'w', newline='') as file:
            wr = csv.writer(file)
            for item in l:
                wr.writerow(item)
        file.close()

        print("Data extracted and saved in file.\n")

        option = input("Do you want to continue? (y/n):")
        if option == 'y':
            continue
        else:
            break



if __name__ == "__main__":
    os.chdir(os.path.dirname(sys.argv[0]))
    cur_dir = os.getcwd()  # Save current directory
    os.makedirs(cur_dir + '/downloads/data/', exist_ok=True)  # Make the directory if it doesn't exist
    file_path = cur_dir + '/downloads/data/indeed_data.csv'  # Store path
    downloadData(file_path)
